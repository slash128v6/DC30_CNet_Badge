CAM files
=======================
The cam files allow you to define which layers are assigned to each gerber file. 
For example, the gerber file GTL (Gerber Top Layer) usually is defined as layer 1 (or top copper). 
If you are using the 4-layer cam, make sure your middle layers are properly assigned. 
