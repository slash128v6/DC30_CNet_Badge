﻿using System;

namespace TiNRSArt
{
    public class Class1
    {
    }
}
